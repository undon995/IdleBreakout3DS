# Original asset reference files

This folder contains the original art/audio reference files supplied for the 3DS port, plus texture atlases and frame-mapping metadata.

- `audio/`: 24 `.ogg` audio files (including alternative variants).
- `sprites/`: 211 extracted `.png` sprite images.
- `atlases/`: two sprite texture atlas images.
- `sprite_map.json`: texture-frame coordinate metadata used by the asset preparation process.

The game currently compiles with preconverted audio/graphics already embedded in `source/audio_data.c` and `source/assets.c`; these raw files are **not** needed to compile the 3DSX or CIA. They are included as a source-material reference for future editing. `cia_assets/` in the repository contains the separate HOME Menu icon, banner, and one-shot sound used during CIA packaging.

## Copyright

The original *Idle Breakout* game and its artwork/audio are by Kodiqi / their respective rights holders. This fan adaptation has no implied permission to republish those assets. **Do not make these files publicly available unless you have permission to redistribute them.** No license to the original game is conveyed by this ZIP.

The original browser-game project archive and website files were deliberately omitted; they are unnecessary for compiling the native 3DS build.
